import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-inci-name',
  templateUrl: './search-inci-name.component.html',
  styleUrls: ['./search-inci-name.component.css']
})
export class SearchINCINameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
