import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-supplier',
  templateUrl: './search-supplier.component.html',
  styleUrls: ['./search-supplier.component.css']
})
export class SearchSupplierComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
