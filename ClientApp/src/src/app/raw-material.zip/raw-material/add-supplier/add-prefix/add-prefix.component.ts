import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-prefix',
  templateUrl: './add-prefix.component.html',
  styleUrls: ['./add-prefix.component.css']
})
export class AddPrefixComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
