import { Component, OnInit } from '@angular/core';
import { AddPrefixComponent } from './add-supplier/add-prefix/add-prefix.component';
import { MatDialog, MatDialogConfig, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SearchINCINameComponent } from './search-inci-name/search-inci-name.component';


@Component({
  selector: 'app-raw-material',
  templateUrl: './raw-material.component.html',
  styleUrls: ['./raw-material.component.css']
})
export class RawMaterialComponent implements OnInit {

  constructor(public dialog: MatDialog) { }
  AddPrefixPopUp(): void {

    const dialogRef = this.dialog.open(AddPrefixComponent, {
      width: '100%',
      minHeight: 'calc(100vh - 90px)',
      height: 'auto', disableClose: true,
    });
  }
  //Searchsupplierpopup(): void {

  //  const dialogRef = this.dialog.open(SearchSupplierComponent, {
  //    width: '940px', height: '650px', disableClose: true,
  //  });
  //}
  SearchINCIpopup(): void {

    const dialogRef = this.dialog.open(SearchINCINameComponent, {
      /*width: '940px', height: '650px',*/ disableClose: true,
      width: '100%',
      minHeight: 'calc(100vh - 90px)',
      height: 'auto'
    });
  }
  ngOnInit() {
  }

}
